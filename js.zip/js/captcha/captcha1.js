// -[INICIO devildrey33.Captcha1]-
var Valor1 = 0;
var Valor2 = 0;

/* Función que genera dos valores aleatorios */
function GenerarCaptcha() {
	Valor1 = 1 + Math.floor(Math.random() * 10);
	Valor2 = 1 + Math.floor(Math.random() * 10);
	document.getElementById("Valor1Captcha").innerHTML = Valor1;
	document.getElementById("Valor2Captcha").innerHTML = Valor2;
	document.getElementById("ResultadoCaptcha").value = "";
}

/* Función que comprueba que el resultado sea la suma de los dos valores generados */
function ValidarCaptcha() {
	if (document.getElementById("ResultadoCaptcha").value == (Valor1 + Valor2)) {
		alert("Tu mensaje ha sido enviado exitosamente.");
		GenerarCaptcha();
	}
	else {
		alert("El valor introducido no es válido.");
	}
}

/* Función que ejecuta el código del cuadro de texto ConsolaJavaScript */
function ConsolaJavaScript() {
	eval(document.getElementById("ConsolaJavaScript").value);
}
// -[FIN devildrey33.Captcha1]-