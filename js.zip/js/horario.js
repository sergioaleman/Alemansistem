//Tabla de horario
function addEvent(o,e,f){if(o.addEventListener){o.addEventListener(e,f,false);return true;}
else if(o.attachEvent){return o.attachEvent("on"+e,f);}
else{return false;}}
addEvent(window,"load",setup);addEvent(window,"unload",makeCookie);function getCookie(path)
{var result="";var a=document.cookie.indexOf(path);if(a!=-1){a+=path.length+1;var b=document.cookie.indexOf(";",a);if(b==-1){b=document.cookie.length;}
result=unescape(document.cookie.substring(a,b));}
return result;}
var cookie_array=null;function processCookie()
{var cookie=getCookie(window.location.pathname);if(cookie!=''){cookie_array=cookie.split(" ");}}
function makeCookie(){var values=((document.getElementById("ampm1").checked)?"1":"0");values+=" "+((document.getElementById("daylight1").checked)?"1":"0");var exp=new Date(new Date().getTime()+30*24*60*60*1000);document.cookie=window.location.pathname+"="+values+"; expires="+exp.toGMTString();}
var locations=["Samoa","Hawaii","Anchorage, Juneau","Seattle, San Francisco, Los Angeles","Edmonton, Denver, Phoenix","Winnipeg, Chicago, Houston, Mexico, Tegucigalpa, Managua, San Jose","New York, Miami, La Habana, Puerto Principe, Panama, Bogota, Quito, Lima","Halifax, Santo Domingo, Caracas, Georgetown, Manaus, La Paz, Asuncion, Santiago de Chile","Brasilia, Rio De Janeiro, Montevideo, Buenos Aires","Recife","Azores","Londres, Dubl&#237;n, Lisboa, Casablanca, Dakar, Accra","Paris, Madrid, Roma, Berl&#237;n, Praga, Belgrado, Varsovia, Estocolmo, Oslo, Argel, Lagos, Brazzaville, Luanda","Helsinki, Minks, Bucarest, Estambul, Atenas, Beirut, Cairo, Tripoli, Harare, Ciudad del Cabo","San Petersburgo, Moscow, Bagdad, Riad, Addis Abeba, Kampala, Nairobi, Mogadisco","Samara, Baku, Tbilisi, Dubai","Sheliabinsk, Karachi, Islamabad","Omsk, Tashkent, Dacca","Novosibirsk, Bangkok, Hanoi, Yakarta","Irkutsk, Lhasa, Beijing, Hong Kong, Kuala Lumpur, Singapur, Manila, Perth","Tokyo, Seul,","Vladivostok, Sydney, Melbourne","Noumea, Magaban","Wellington (Nueva Zelanda)"];function setup()
{processCookie();setup_disp();if(cookie_array){document.getElementById("ampm"+cookie_array[0]).checked=true;document.getElementById("daylight"+cookie_array[1]).checked=true;}
update_clock();}
function setup_disp()
{s="<table class=\"tabla\">";s+="<tr><td class=\"ccm\" colspan=\"2\">";s+="<input id=\"ampm0\" type=\"radio\" name=\"ampm\" checked=\"checked\">24 horas&nbsp;";s+="<input id=\"ampm1\" type=\"radio\" name=\"ampm\">AM/PM";s+="</td><td width=\"220px\" class=\"ccm\">";s+="<input id=\"daylight0\" type=\"radio\" name=\"daylight\" checked=\"checked\">Standard<br />";s+="<input id=\"daylight1\" type=\"radio\" name=\"daylight\">Hora de verano";s+="</td></tr>";s+="<tr bgcolor=\"#ccffcc\"><td class=\"ccb\">Zona</td>";s+="<td class=\"ccb\">Lugar</td>";s+="<td class=\"ccb\" >Fecha/Hora</td></tr>";daylight=(cookie_array&&cookie_array[1]=="1")?1:0;offset=(new Date().getTimezoneOffset()/60)+daylight;for(i=0;i<24;i++){q="tz"+i;j=i-11;si=""+Math.abs(j)
if(si.length<2)si="0"+si;si=((j<0)?"-":"+")+si;mod=(i-11==-offset)?" bgcolor=\"#f0f0ff\"":"";s+="<tr"+mod+" id=\"row"+i+"\"><td class=\"cc\">UTC"+si+"</td>";s+="<td class=\"cc\">"+locations[i]+"</td>";s+="<td class=\"ccm\" id=\"v"+i+"\"></td></tr>";}
s+="</table>";document.getElementById("clock_disp").innerHTML=s;}
function lz(v)
{return(v<10)?"0"+v:v;}
function formatDate(d)
{s=lz((d.getMonth()+1))+"/"+lz(d.getDate())+"/"+d.getFullYear()+" ";h=d.getHours();if(document.getElementById("ampm1").checked){ap=(h>=12)?"PM":"AM";h=(h%12);if(h==0)h=12;s+=lz(h)+":"+lz(d.getMinutes())+":"+lz(d.getSeconds())+" "+ap;}
else{s+=lz(h)+":"+lz(d.getMinutes())+":"+lz(d.getSeconds());}
return s;}
var old_offset=-1;var hour=3600000;function update_clock(){d=new Date();offset=d.getTimezoneOffset()/60;daylight=(document.getElementById("daylight1").checked)?1:0;offset+=daylight;d.setTime(d.getTime()-(11*hour)+offset*hour);for(i=-11;i<=12;i++){document.getElementById("v"+(i+11)).innerHTML=formatDate(d);if(old_offset!=offset){color=(i==-offset)?"#f0f0ff":"#ffffe0";document.getElementById("row"+(i+11)).style.background=color;}
d.setTime(d.getTime()+hour);}
old_offset=offset;setTimeout('update_clock()',990);}
//Reloj
function doClock(){setTimeout("doClock()",1e3);t=new Date;m=t.getMonth();d=t.getDay();dt=t.getDate();y=t.getFullYear();h=t.getHours();if(h<12){ap="AM"}else{ap="PM";h=h-12}mn=pad(t.getMinutes());s=pad(t.getSeconds());if(h==0){h=12}clockID.innerHTML="Fecha y hora en esta computadora o dispositivo: "+calDays[d]+", "+dt+" de "+months[m]+" del "+y+" "+h+":"+mn+":"+s+" "+ap}function pad(a){if(a<10){a="0"+a}return a}months=new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");calDays=new Array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado")
//Convertir hora
function workOutNewTime(newTimeinMinutes){var newTimeinHour=0;while(newTimeinMinutes>59){newTimeinMinutes-=60;newTimeinHour++;}
if(newTimeinHour<10){newTimeinHour="0"+newTimeinHour}
if(newTimeinMinutes<10){newTimeinMinutes="0"+newTimeinMinutes}
finalTime=newTimeinHour+":"+newTimeinMinutes;return finalTime;}
function ampmTime(newTimeinMinutes){var newTimeinHour=0;while(newTimeinMinutes>59){newTimeinMinutes-=60;newTimeinHour++;}
if(newTimeinMinutes<10){newTimeinMinutes="0"+newTimeinMinutes}
finaltime=newTimeinHour+":"+newTimeinMinutes
return finaltime;}
function timecalc(){var userhours;var hoursvalue=document.ciudad.hours.value;if(document.ciudad.radio2[1].checked==1){if(hoursvalue==1){hoursvalue=13}
if(hoursvalue==2){hoursvalue=14}
if(hoursvalue==3){hoursvalue=15}
if(hoursvalue==4){hoursvalue=16}
if(hoursvalue==6){hoursvalue=18}
if(hoursvalue==7){hoursvalue=19}
if(hoursvalue==8){hoursvalue=20}
if(hoursvalue==9){hoursvalue=21}
if(hoursvalue==10){hoursvalue=22}
if(hoursvalue==11){hoursvalue=23}
if(hoursvalue==12){hoursvalue=24}
var userhours=hoursvalue*60;}else{var userhours=hoursvalue*60;}
if(document.ciudad.minutes.value==""){document.ciudad.minutes.value="00"}
var usertime=userhours+parseInt(document.ciudad.minutes.value);var offsetminutes=document.ciudad.selection2.options[document.ciudad.selection2.selectedIndex].value;var lastcity=document.ciudad.selection3.options[document.ciudad.selection3.selectedIndex].value;var finaltime=timeValue(offsetminutes,usertime,lastcity);document.ciudad.textbox2.value=timeDate;}
function timeValue(offsetminutes,usertime,lastcity){day="del mismo dia";if(offsetminutes>=0){gmttime=parseInt(usertime-offsetminutes);}else{offsetminutes=offsetminutes*-1;var gmttime=parseInt(offsetminutes+usertime);}
if(gmttime<0){day="del dia anterior";gmttime=1440+parseInt(gmttime);}
if(lastcity>0){var rstime=parseInt(lastcity)+(gmttime);}else{rstime=parseInt(lastcity)+(gmttime)}
if(rstime>1440){day="del dia siguiente";rstime=rstime-1440;}
if(rstime<0){day="del dia anterior";rstime=(1440)+(rstime);}
if(document.ciudad.radio2[2].checked==1){ftime=workOutNewTime(rstime)}else{ftime=ampmTime(rstime)}
timeDate=ftime+"  "+day;return timeDate;}
var tempo=null;var tempoOn="false";function stopIt(){if(tempoOn){clearTimeout(tempo)
tempoOn=false;}}
function gettime(){var now=new Date();var hournow=now.getUTCHours();if(hournow<10){hournow="0"+hournow}
var minutesnow=now.getUTCMinutes();if(minutesnow<10){minutesnow="0"+minutesnow}
var secondsnow=now.getUTCSeconds();if(secondsnow<10){secondsnow="0"+secondsnow}
tv=hournow+":"+minutesnow+":"+secondsnow
var hournowlocal=now.getHours();var minutesnowlocal=now.getMinutes();if(minutesnowlocal<10){minutesnowlocal="0"+minutesnowlocal}
document.getElementById('hora_gmt').innerHTML=tv;document.ciudad.hours.value=hournowlocal
document.ciudad.minutes.value=minutesnowlocal
tempo=setTimeout("gettime()",1000);tempoOn="true";}
function init(){stopIt();gettime();}
var isNew=0;var isNS4=0;var isIE4=0;var brow=((navigator.appName)+(parseInt(navigator.appVersion)));if(parseInt(navigator.appVersion>=5)){isNew=1}else if(brow=="Netscape4"){isNS4=1;}else if(brow=="Microsoft Internet Explorer4"){isIE4=1;}
docObj=(isNS4)?'document':'document.all';styleObj=(isNS4)?'':'.style';function lyroff(currElem){dom=eval(docObj+'.'+currElem+styleObj);state=dom.visibility;if(state=="visible"||state=="show"){dom.visibility="hidden";}}
function lyron(currElem){dom=eval(docObj+'.'+currElem+styleObj);state=dom.visibility;if(state=="hide"||state=="hidden"){dom.visibility="visible"};}
function tzone(timediff){var now=new Date();var hour=now.getUTCHours();var minutes=now.getUTCMinutes();newTimeinMinutes=(hour*60)+minutes+timediff;var newTimeinHour=0;if(newTimeinMinutes>1440){day=" next day";newTimeinMinutes-=1440;}
else if(newTimeinMinutes<0){day=" previous day";newTimeinMinutes*=-1;}
else{day="";}
while(newTimeinMinutes>59){newTimeinMinutes-=60;newTimeinHour++;}
if(newTimeinMinutes<10){newTimeinMinutes="0"+newTimeinMinutes}
var thistime=newTimeinHour+":"+newTimeinMinutes+day;return thistime;}
function shownote(evt,currElem){if((isNS4&&currElem!=0)||(isIE4&&currElem!=0)){dom=eval(docObj+'.'+currElem+styleObj);}
state=dom.visibility;if(state=="visible"||state=="show"){dom.visibility="hidden";}
else{if(isNS4){topVal=eval(evt.pageY+1);leftVal=eval(evt.pageX-250);}
if(isIE4){topVal=eval(event.y+1);leftVal=eval(event.x-250);}
if(leftVal<2){leftVal=2;}
dom.top=topVal;dom.left=leftVal;dom.visibility="visible";}}