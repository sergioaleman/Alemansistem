<?php
$txpcfg['db'] = 'serale1_ei';
$txpcfg['user'] = 'serale1_ei';
$txpcfg['pass'] = 'a2l7f618';
$txpcfg['host'] = 'localhost';
$txpcfg['table_prefix'] = 'a2055l1f18_';
$txpcfg['txpath'] = '/home/www/boludo.com.ve//home/textpattern';
$txpcfg['dbcharset'] = 'utf8';
?>